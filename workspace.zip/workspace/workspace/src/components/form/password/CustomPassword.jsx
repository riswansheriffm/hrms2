import React, { useState } from "react";
import styles from "./styles.module.css";
import PropTypes from "prop-types";

export default function CustomPassword({
  id,
  name,
  defaultValue,
  style,
  className,
  labelText,
  labelStyle,
  labelClassName,
  register,
  required,
  validation,
  placeholder,
  disabled,
  tagNeeded,
  control,
}) {
  const [visible, setVisible] = useState(false);
  return (
    <>
      <label
        htmlFor={id}
        style={labelStyle}
        className={`block ${labelClassName}`}
      >
        {labelText}
      </label>

      <div
        className={`${styles.pass} p-password p-component p-inputwrapper p-input-icon-right`}
        data-pc-name="password"
        data-pc-section="root"
      >
        <div
          className="p-icon-field p-icon-field-right"
          data-pc-name="iconfield"
          data-pc-section="root"
        >
          <input
            className={`${className} ${styles.pass}  p-password-input p-inputtext p-component`}
            tabIndex="0"
            type={visible ? "text" : "password"}
            data-pc-section="root"
            data-pc-name="inputtext"
            id={id}
            name={name}
            placeholder={placeholder}
            defaultValue={defaultValue}
            style={style}
            {...register(
              name,
              required && {
                required: required,
                validate: validation,
              }
            )}
            disabled={disabled}
          />
          <span
            className="p-input-icon"
            data-pc-name="inputicon"
            data-pc-section="root"
            onClick={() => setVisible((prev) => !prev)}
          >
            <svg
              width="14"
              height="14"
              viewBox="0 0 14 14"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="p-icon p-password-show-icon"
              role="switch"
              aria-label="Show Password"
              aria-hidden="true"
              tabIndex="0"
              aria-checked="true"
              data-pc-section="showicon"
            >
              <path
                fillRule="evenodd"
                clipRule="evenodd"
                d="M0.0535499 7.25213C0.208567 7.59162 2.40413 12.4 7 12.4C11.5959 12.4 13.7914 7.59162 13.9465 7.25213C13.9487 7.2471 13.9506 7.24304 13.952 7.24001C13.9837 7.16396 14 7.08239 14 7.00001C14 6.91762 13.9837 6.83605 13.952 6.76001C13.9506 6.75697 13.9487 6.75292 13.9465 6.74788C13.7914 6.4084 11.5959 1.60001 7 1.60001C2.40413 1.60001 0.208567 6.40839 0.0535499 6.74788C0.0512519 6.75292 0.0494023 6.75697 0.048 6.76001C0.0163137 6.83605 0 6.91762 0 7.00001C0 7.08239 0.0163137 7.16396 0.048 7.24001C0.0494023 7.24304 0.0512519 7.2471 0.0535499 7.25213ZM7 11.2C3.664 11.2 1.736 7.92001 1.264 7.00001C1.736 6.08001 3.664 2.80001 7 2.80001C10.336 2.80001 12.264 6.08001 12.736 7.00001C12.264 7.92001 10.336 11.2 7 11.2ZM5.55551 9.16182C5.98308 9.44751 6.48576 9.6 7 9.6C7.68891 9.59789 8.349 9.32328 8.83614 8.83614C9.32328 8.349 9.59789 7.68891 9.59999 7C9.59999 6.48576 9.44751 5.98308 9.16182 5.55551C8.87612 5.12794 8.47006 4.7947 7.99497 4.59791C7.51988 4.40112 6.99711 4.34963 6.49276 4.44995C5.98841 4.55027 5.52513 4.7979 5.16152 5.16152C4.7979 5.52513 4.55027 5.98841 4.44995 6.49276C4.34963 6.99711 4.40112 7.51988 4.59791 7.99497C4.7947 8.47006 5.12794 8.87612 5.55551 9.16182ZM6.2222 5.83594C6.45243 5.6821 6.7231 5.6 7 5.6C7.37065 5.6021 7.72553 5.75027 7.98762 6.01237C8.24972 6.27446 8.39789 6.62934 8.4 7C8.4 7.27689 8.31789 7.54756 8.16405 7.77779C8.01022 8.00802 7.79157 8.18746 7.53575 8.29343C7.27994 8.39939 6.99844 8.42711 6.72687 8.37309C6.4553 8.31908 6.20584 8.18574 6.01005 7.98994C5.81425 7.79415 5.68091 7.54469 5.6269 7.27312C5.57288 7.00155 5.6006 6.72006 5.70656 6.46424C5.81253 6.20842 5.99197 5.98977 6.2222 5.83594Z"
                fill="currentColor"
              ></path>
            </svg>
          </span>
        </div>
      </div>
      {React.cloneElement(tagNeeded || <p className="my-0"></p>, {
        control,
      })}
    </>
  );
}

CustomPassword.propTypes = {
  className: PropTypes.string,
  id: PropTypes.string.isRequired,
  name: PropTypes.string.isRequired,
  defaultValue: PropTypes.string,
  labelText: PropTypes.string,
  labelStyle: PropTypes.object,
  labelClassName: PropTypes.string,
  register: PropTypes.func.isRequired,
  required: PropTypes.string,
  validation: PropTypes.func,
  style: PropTypes.object,
  placeholder: PropTypes.string,
};
