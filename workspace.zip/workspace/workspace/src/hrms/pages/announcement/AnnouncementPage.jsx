const AnnouncementPage = () => {
  return <div>Announcement Page - coming soon</div>;
};

export default AnnouncementPage;
