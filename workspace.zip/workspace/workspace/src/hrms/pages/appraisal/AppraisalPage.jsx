const AppraisalPage = () => {
  return <div>AppraisalPage</div>;
};

export default AppraisalPage;
