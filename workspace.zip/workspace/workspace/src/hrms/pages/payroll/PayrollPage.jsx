const PayrollPage = () => {
  return <div>PayrollPage</div>;
};

export default PayrollPage;
