const YourOffer = () => {
  return <div>YourOffer</div>;
};

export default YourOffer;
