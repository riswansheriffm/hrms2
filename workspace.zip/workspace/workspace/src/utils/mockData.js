export const userMockData = new Promise((resolve) =>
  setTimeout(
    () =>
      resolve({
        id: "1",
        code: "f230fh0g3",
        name: "Bamboo Watch",
        description: "Product Description",
        image: "bamboo-watch.jpg",
        price: 65,
        category: "Accessories",
        quantity: 24,
        inventoryStatus: "INSTOCK",
        rating: 5,
      }),
    1000
  )
);
